import java.util.*;

public class Game {	
	private TaskGame gui; // Pour l'interface pour dessiner
	int colonne,ligne;
	boolean aideActive =false;

	private static Scanner input = new Scanner(System.in);

	public Game(TaskGame gui){
		this.gui = gui;
	}

	public void launch(){
		boolean terminerProgramme=false;
		while (terminerProgramme==false){
			Board plateau;
			System.out.println("Chargement du jeu");
			System.out.println("=========================================");
			plateau = initialisationGrille();
			System.out.println("=========================================");
			plateau.afficheBoard();
			System.out.println("=========================================");
			actualisation(plateau);
			// choixAide();
			
			ordiOuHumain(plateau);
			System.out.println("=========================================");
			plateau.gagnantJeu();  ///////////FONCTION GAGNANT JEU //////////
			System.out.println("=========================================");
			terminerProgramme=finirJeu();  //////////// FONCTION CONTINUER JEU /////////

		}

	}



	/////////////////////////////////////////////////////////////////// FONCTION JOUER CONTRE UN HUMAIN //////////////////////////////////////
	public void jouerContreHumain(Board plateau){
		System.out.println("Le joueur qui commence,");
		int JoueurActuel=choixCouleur();
		int JoueurAdverse=couleurOppose(JoueurActuel);


		while (plateau.caseVide()==true && plateau.rougeBleuePresente()/* && plateau.caseJouable(JoueurActuel,JoueurAdverse) */) {   /////TANT QU'IL Y A DES CASES VIDES ET ET DEUX COULEURS SUR LE PLATEAU

			if (JoueurActuel==1){
				System.out.println("Tour du joueur rouge");
				tourHumain(JoueurActuel,JoueurAdverse,plateau);// ici on mettra une Fonction qui lance le tour avec pour variable (JoueurActuel , JoueurAdverse)

				JoueurActuel=couleurOppose(JoueurActuel);
				JoueurAdverse=couleurOppose(JoueurAdverse);
				plateau.afficheBoard();
			}

			else if (JoueurActuel==2){
				System.out.println("Tour du joueur bleue");
				tourHumain(JoueurActuel,JoueurAdverse,plateau);//ici on mettra une Fonction qui lance le tour avec pour variable (JoueurActuel, JoueurAdverse)

				JoueurActuel=couleurOppose(JoueurActuel);
				JoueurAdverse=couleurOppose(JoueurAdverse);
				plateau.afficheBoard();
			}

		}

	}
	///////////////////////////////////////////////////////////////////FONCTION JOUER CONTRE UN ORDINATEUR ////////////////////////////////////

	public void jouerContreOrdinnateur(Board plateau){
		int joueur= choixCouleur();  // 2 sera bleue , 1 sera rouge //
		int ordinnateur= couleurOppose(joueur); // couleur oppos�


		int joueurActuel=quiCommence(joueur,ordinnateur);  // Retourne la couleur du joueur si Oui , sinon la couleur de l'ordinnateur
		int joueurAdverse=couleurOppose(joueurActuel); // Retourne la couleur oppose 

		while (plateau.caseVide()==true && plateau.rougeBleuePresente()/* &&plateau.caseJouable(JoueurActuel, JoueurAdverse)*/){  ////TANT QU'IL Y A DES CASES VIDES ET DEUX COULEURS SUR LE PLATEAU

			if (joueurActuel==joueur){

				System.out.println("Tour de l'humain");
				tourHumain(joueur,ordinnateur,plateau);

				joueurActuel=couleurOppose(joueurActuel);
				joueurAdverse=couleurOppose(joueurAdverse);
			}

			else if(joueurActuel==ordinnateur){

				System.out.println("Tour de l'ordinnnateur");
				tourOrdinnateur(ordinnateur,joueur,plateau);

				joueurActuel=couleurOppose(joueurActuel);
				joueurAdverse=couleurOppose(joueurAdverse);
			}
		}



	}

	///////////////////////////////////////////////////////////////////////TOUR D'HUMAIN//////////////////////////////

	public void tourHumain(int Joueur,int Adversaire,Board plateau){  // va prendre la couleur du joueur qui joue et la couleur de l'adversaire
		boolean fini=false;
		int[] coordonnee=new int[2];
		int[][] pointsModifier = new int[plateau.ligneTab()*plateau.colonneTab(1)][2];
		pointsModifier[0][0]=0; // LA PREMIERE COLONNE DU PREMIER PETIT TABLEAU DONNE LE NOMBRE DE POINT
		pointsModifier[0][1]=0;
		while (fini==false){
			
			/*int[][] tableauDePointDispo= new int[plateau.ligneTab()*plateau.colonneTab(0)][2];
			tableauDePointDispo=colorierPointDispo(plateau,Joueur,Adversaire,tableauDePointDispo);*/
			
			waitForMouseClick();
			coordonnee[1]=getX(); // Le x correspond � la colonne
			coordonnee[0]=getY(); // Le y correspond � la ligne
			
			
			// decoloriePointDispo(tableauDePointDispo);
			
			if (plateau.caseDejaPrise(coordonnee[0],coordonnee[1])==true){
				fini=true; 
			}
			else if (plateau.caseAdverseAutour(coordonnee[0],coordonnee[1],Adversaire)==true){
				plateau.rechercherChemin(pointsModifier,coordonnee,Joueur,Adversaire);			
				if (pointsModifier[0][0]!=0){
					plateau.modifierBoard(pointsModifier,Joueur);
					colorieListeDeTableau(pointsModifier,Joueur);
					fini=true;
				}
				else{
					System.out.println("Mauvaise Case");
				}

			}
			
		}
	}


	/////////////////////////////////////////////////////////////// IA ORDINNATEUR ////////////////////////////////
	public void tourOrdinnateur(int Ordi,int Adversaire,Board plateau){

		int[][] Pointamodifier = new int[plateau.ligneTab()*plateau.colonneTab(1)][2];
		Pointamodifier[0][0]=0;
		plateau.rechercherCheminOrdi(Pointamodifier,Ordi,Adversaire);
		System.out.println(" "+ Pointamodifier[0][0]);
		if (Pointamodifier[0][0]!=0){
			System.out.println(" "+ Pointamodifier[0][0]);
			plateau.modifierBoard(Pointamodifier,Ordi);
			colorieListeDeTableau(Pointamodifier,Ordi);
		}

	}




	///////////////////////////////////////////////////////////////////////////////////////////////////////CHOIX DEBUT DE PARTI////////////////////////

	public int quiCommence(int Joueur,int Ordi){
		int OuiouNon;
		boolean fini=false;

		System.out.println("Voulez-vous commencer ?");
		while(fini==false){

			System.out.println("(1) Oui");
			System.out.println("(2) Non");

			OuiouNon = input.nextInt();

			if (OuiouNon==1){

				return Joueur;
			}
			else if (OuiouNon==2){

				return Ordi;
			}
		}
		return 0;
	}
	/* public void choixAide(){
		int choix=0;
		System.out.println("Voulez-vous qu'on vous indique les cases jouables ?");

		while(choix !=1 & choix !=2){ // VA BOUCLER TANT QUE LE CHOIX N'EST PAS 1 OU 2
			System.out.println("(1) Oui");
			System.out.println("(2) Non");
			choix = input.nextInt();
		}
			if (choix==1){
				aideActive=true;  // MODIFIE LA VARIABLE GLOBAL aideActive
			}
			else{
				aideActive=false;
			}

		
	} */
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////// FONCTION DEBUT DE PARTI CHOIX DES tourS /////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


	//////////////////////////////////////////initialiSATION DE GRILLE///////////////////////////////////////////
	public Board initialisationGrille(){
		int ligne=0;
		int colonne=0;

		boolean pair=false;
		System.out.println("Initialisation du plateau");
		System.out.println("Entrez la largeur de la grille");

		while(pair==false){  /// Petite boucle pour s'assurer que la largeur est pair
			colonne = input.nextInt();
			if (colonne % 2==0 && colonne>=8){
				pair= true;
			}
			else{
				System.out.println(" /!\\ Entrez une grille paire et minimum �gale � 8");
			}
		}
		pair=false;
		System.out.println("Entrez la longueur de la grille");

		while(pair==false){    // Petite boucle pour s'assurer que la longueur est pair
			ligne = input.nextInt();
			if (ligne%2==0 && ligne>=8){
				pair= true;
			}
			else{
				System.out.println("/!\\ Entrez une grille paire et minimum �gale � 8");
			}
		}
		Board plateau = new Board(ligne,colonne);
		drawGrid(colonne,ligne);  // Bien faire attention que le drawGrid prend les colonnes puis les lignes //
		return plateau;
	}
	/////////////////////////////////////////////////////////////////////////CHOIX ORDINNATEUR OU HUMAIN///////////////////////////////
	public void ordiOuHumain(Board plateau){
		int typePartie;
		boolean partielance =false;

		System.out.println("Contre qui voulez-vous jouer?");
		while(partielance==false){
			System.out.println("(1) Humain");
			System.out.println("(2) Ordinateur");
			typePartie = input.nextInt();

			if (typePartie == 1){
				partielance=true;
				jouerContreHumain(plateau);
			}
			else if(typePartie == 2){
				partielance=true;
				jouerContreOrdinnateur(plateau);
			}
		}
	}
	////////////////////////////////////////////////////////////////CHOIX COULEUR D'UN JOUEUR//////////////////////////

	public int choixCouleur(){ // Va retourner 1 si le choix est Rouge et va retourner 2 si le choix est bleue
		int couleurJoueur = 0;
		boolean choixCouleur=false;
		System.out.println("Choisissez votre couleur :");
		while(choixCouleur==false){
			System.out.println("(1) Rouge");
			System.out.println("(2) Bleue");
			couleurJoueur = input.nextInt();

			if (couleurJoueur == 2 || couleurJoueur == 1){
				choixCouleur=true;
			}
		}
		return couleurJoueur;
	}
	//////////////////////////////////////////////////////FONCTION REFAIRE UN MATCH///////////////////////////////////

	public boolean finirJeu(){
		boolean choix=false;
		int numchoix=0;
		System.out.println("Voulez-vous refaire une partie ?");
		while (numchoix != 1 && numchoix != 2){
			System.out.println("(1) Oui");
			System.out.println("(2) Non");
			numchoix=input.nextInt();
		}
		if (numchoix==2){
			choix=true;
		}
		return choix;
	}



	/////////////////////////////////////////////////////////////////////FONCTION COULEUR OPPOSE/////////////////////////

	public int couleurOppose(int CouleurDeBase){  //Fonction donnant la couleur oppos�

		if (CouleurDeBase==1){
			return 2;
		}

		else if (CouleurDeBase==2){
			return 1;
		}

		return 3;
	}
	/////////////////////////////////////////////////////////////////////FONCTION COLORIER//////////////////////////////////////////////
	public void colorieListeDeTableau(int[][] TableauDePoint,int Joueur){
		int Ligne;
		int Colonne;
		for(int i=1;i<=TableauDePoint[0][0];i++){
			Ligne=TableauDePoint[i][0];
			Colonne=TableauDePoint[i][1];
			colorierPoint(Ligne,Colonne,Joueur);	
		}

	}

	public void colorierPoint(int Ligne,int Colonne,int Joueur){
		if(Joueur==1){
			drawRedSquare(Colonne,Ligne);
		}
		if(Joueur==2){
			drawBlueSquare(Colonne,Ligne);
		}
		if(Joueur==3){
			drawGreenSquare(Colonne,Ligne);
		}
		if(Joueur==0){
			drawWhiteSquare(Colonne,Ligne);
		}
	}
	 public int[][] colorierPointDispo(Board plateau,int Joueur,int Adversaire,int[][] tableauDePoint){
		if (aideActive==true){
			tableauDePoint= plateau.rechercheCoupValide(Joueur,Adversaire);
		}
		colorieListeDeTableau(tableauDePoint,3);
		return tableauDePoint;
	}
	public void decoloriePointDispo(int[][] tableauDePoint){
		colorieListeDeTableau(tableauDePoint,0);
	}
	////////////////////////////////////////////////////////////////////FONCTION ACTUALISATION /////////////////////////////

	public void actualisation(Board plateau){ // A utiliser en dernier recours -> redessine toutes la grille //
		for(int i=0;i <= plateau.ligneTab()-1 ;i++){  // On incremente sur toute les lignes
			for(int j=0; j<= plateau.colonneTab(i)-1;j++){     

				if (plateau.valeurTab(i,j)==1){       
					drawRedSquare(j, i);
				}
				else if (plateau.valeurTab(i,j)==2){
					drawBlueSquare(j,i);
				}
				else if (plateau.valeurTab(i,j)==0){
					drawWhiteSquare(j,i);
				}
				else if (plateau.valeurTab(i,j)==3){
					drawGreenSquare(j,i);
				}

			}
		}
	}

	//////////////////////////////////////////////////A PARTIR D'ICI FONCTION A NE PAS MODIFIER /////////////////////////////

	// Attend qu'il y ait un click de souris sur la grille
	private void waitForMouseClick() {
		gui.waitForMouseClick();
	}

	// Abscisse du clic
	private int getX() {
		return gui.getX();
	}

	// Ordonnee du clic
	private int getY() {
		return gui.getY();
	}

	// Dessine une grille vide de taille sizeAbs x sizeOrd
	private void drawGrid(int sizeAbs, int sizeOrd) {
		gui.drawGrid(sizeAbs, sizeOrd);
	}

	// Dessine un carre rouge en (x, y)
	private void drawRedSquare(int x, int y) {
		gui.drawRedSquare(x, y);
	}

	// Dessine un carre bleu en (x, y)
	private void drawBlueSquare(int x, int y) {
		gui.drawBlueSquare(x, y);
	}

	private void drawGreenSquare(int x, int y) {
		gui.drawGreenSquare(x, y);
	}

	private void drawWhiteSquare(int x, int y) {
		gui.drawWhiteSquare(x, y);
	}

}
