

public class Board {
	private int[][] tableau ; 

	public Board(int nb_lignes, int nb_colonnes){ 
		/// CONSTRUCTEUR

		tableau=new int[nb_lignes][nb_colonnes];
		for(int i=0;i<=nb_lignes-1; ++i) {
			for(int j=0;j<=nb_colonnes-1; ++j) {
				tableau[i][j]=0;
			}    
		}
		//on suppose les dimensions du tableau sont paires ,on testera cette condition au pr�alable
		//rouge = 1
		//bleu = 2
		tableau[nb_lignes/2-1][(nb_colonnes/2)-1]=1;
		tableau[nb_lignes/2-1][nb_colonnes/2]=2;
		tableau[nb_lignes/2][(nb_colonnes/2)-1]=2;
		tableau[nb_lignes/2][(nb_colonnes)/2]=1;

	}



	public void afficheBoard(){            // Permet d'afficher tout le tableau dans la console
		for(int i=0;i<= tableau.length -1;i++){  
			// On incremente i de 0 au nombre de ligne du tableau
			System.out.print('[');
			for(int j=0;j<= tableau[i].length -1;j++){
				// On increment j de 0 au nombre de colonne de chaque ligne	
				System.out.print(tableau[i][j]+" ");
			}
			System.out.print(']');
			System.out.println(' ');
		}
	}

	public void modifierBoard(int num_ligne, int num_colonne,int nouvelle_valeur){ ///// DEUX FONCTION MODIFIER BOARD ICI CELLE QUI MODIFIE QU'UN SEUL ELEMENT
		// Fonction qui permet de modifier une case pr�cise du tableau
		// Faire attention que le tableau commence a 0 //

		tableau[num_ligne][num_colonne]= nouvelle_valeur;
	}



	public int valeurTab(int num_ligne,int num_colonne){
		/// RETOURNE UNE VALEUR DU TABLEAU (1 ROUGE /2 BLEU/0 BLANC)
		return tableau[num_ligne][num_colonne];
	}

	public int ligneTab(){  // Nous renvois le nombre de ligne du tableau
		return tableau.length;
	}




	public int colonneTab(int num_ligne){ // Nous renvois le nombre de colonne  pour une ligne pr�cise ( toute les lignes auront le meme nombre normalement)
		return tableau[num_ligne].length;  

	}





	public boolean caseVide(){    // Nous renvois si il existe des cases encore disponible ou pas
		boolean CasePossible=false;

		for(int i=0;i<=tableau.length-1;i++){

			for(int j=0; j<= tableau.length-1 ;j++){

				if ( tableau[i][j]== 0 ){
					CasePossible=true;
				}
			}
		}
		return CasePossible;	
	}

	public boolean caseDejaPrise(int ligne,int colonne){          /// VERIFIE SI LA CASE ACTUELLE EST BIEN VIDE
		boolean prise=false;
		if ( tableau[ligne][colonne] != 0){
			prise=true;
		}
		return prise;
	}

	public int[][] rechercheCoupValide(int Joueur,int Adversaire){
		int[][] tableauDePoint= new int[ligneTab()*colonneTab(0)][2];
		tableauDePoint[0][0]=0;
		int MaxLigne= tableau.length-1;
		int MaxColonne= tableau[0].length-1;

		for(int i= 0;i<=MaxLigne;i++){
			for(int j=0;j<=MaxColonne;j++){
				int[] coordonnee = new int[2];
				int[][] listeDePointModifie= new int[ligneTab()*colonneTab(0)][2];
				coordonnee[0]=i;
				coordonnee[1]=j;
				rechercherChemin(listeDePointModifie,coordonnee,Joueur,Adversaire);
				if (listeDePointModifie[0][0] != 0){

					tableauDePoint[0][0]+=1;
					tableauDePoint[tableauDePoint[0][0]]=coordonnee;
				}
			}
		}
		return tableauDePoint;
	}

	public boolean caseAdverseAutour(int ligne,int colonne,int Adversaire){
		// MaxLigne sera le nombre de ligne total ( on commence a 0 donc MaxLigne-1 sera le maximum autoris�)
		boolean caseadversepresente=false;
		int MaxLigne = tableau.length;
		int MaxColonne = tableau[0].length;
		for(int i=-1;i<2 && caseadversepresente==false;i++){

			for(int j=-1; j<2 && caseadversepresente==false; j++){

				if (ligne+i < 0 || ligne+i > MaxLigne-1 || colonne+j < 0 ||colonne+j > MaxColonne-1){	
				}
				else{
					if ( tableau[ligne+i][colonne+j]==Adversaire){
						caseadversepresente=true;
					}
				}

			}
		}
		return caseadversepresente;	
	}
	/* public boolean caseJouable(int joueur,int adversaire){
		boolean caseJouable = false;
		for(int ligne=1;(ligne<=tableau.length && caseJouable==false);ligne++){
			
			for(int colonne=1;(colonne<=tableau[0].length && caseJouable==false);colonne++){
				
				int[][] pointsModifier1 = new int[tableau.length*tableau[0].length][2]; 
				int[][] pointsModifier2 = new int[tableau.length*tableau[0].length][2];
				int[] coordonnee = new int[2];
				coordonnee[0]=ligne;
				coordonnee[1]=colonne;
				rechercherChemin(pointsModifier1,coordonnee,joueur,adversaire);
				rechercherChemin(pointsModifier2,coordonnee,adversaire,joueur);
				if (pointsModifier1[0][0]!=0 && pointsModifier2[0][0]!=0 ){
					caseJouable=true;
				}
			}
		}
		return caseJouable;

	} */

	public void rechercherChemin(int[][] pointsModifier,int[] coordonnee,int joueur,int adversaire){  
		////VA RECHERCHE UNE CASEAVERSE AUTOUR ET VA LANCER LA FONCTION continuerVersDIRECTION
		int ligne=coordonnee[0];
		int colonne=coordonnee[1];


		for(int i=-1;i<2;i++){

			for (int j=-1;j<2;j++){ // On va balayer toutes les cases autour de notre coordonnee de clics

				if (!(ligne+i> tableau.length-1 || ligne+i <0 || colonne+j > tableau[0].length-1 || colonne+j <0 || (i==0 && j==0))){

					if( tableau[ligne+i][colonne+j]==adversaire){

						continuerVersDirection(coordonnee,i,j,joueur,pointsModifier);

					}
				}
			}
		}
	}

	public void rechercherCheminOrdi(int[][] Pointamodifier,int Ordi,int Adversaire){  
		// VA GARDER LE MEILLEUR CHEMIN POSSIBLE EN TESTANT CHAQUE CASE VIA LA FONCTION rechercherChemin
		int MaxLigne = tableau.length-1;
		int MaxColonne = tableau[0].length-1;

		for (int Ligne=0;Ligne<= MaxLigne;Ligne++){  /// Le max accessible est toujours la taille du tableau-1 car le 0 est inclus.

			for(int Colonne=0;Colonne<= MaxColonne;Colonne++){

				if (caseAdverseAutour(Ligne,Colonne,Adversaire)==true & caseVide(Ligne,Colonne) ) {
					int[] coordonnee= new int[2];
					coordonnee[0]=Ligne;
					coordonnee[1]=Colonne;

					int[][] PointamodifierTempo = new int[(MaxLigne+1)*(MaxColonne+1)][2];	
					PointamodifierTempo[0][0]=0;

					rechercherChemin(PointamodifierTempo,coordonnee,Ordi,Adversaire);

					if (Pointamodifier[0][0] < PointamodifierTempo[0][0]){						
						devientCeTableau(Pointamodifier,PointamodifierTempo);
					}
				}
			}
		}
	}
	public void devientCeTableau(int[][] Pointamodifier,int[][] pointTemporaire){
		// AFFILIE CHAQUE VALEUR D'UN TABLEAU A UN AUTRE TABLEAU (TABLEAU DE BASE AVEC FORCEMENT MOINS DE VALEUR)
		int Maxtempo= pointTemporaire.length;
		Pointamodifier[0][0]= pointTemporaire[0][0];

		for (int i=1;i<Maxtempo;i++){
			Pointamodifier[i]=pointTemporaire[i];
		}
	}

	public void continuerVersDirection(int[] coordonnee,int directionLigne,int directionColonne,int couleurAtrouver,int[][] pointsModifier){
		/// CONTINUER VERS DIRECTION VA RECUPERER UN CHEMIN ET L'AJOUTER AU TOTAL DE POINT A MODIFIER (N'AJOUTE RIEN SI IL TOMBE SUR UN MUR/OU UNE CASE VIDE
		int ligne=coordonnee[0];
		int colonne=coordonnee[1];
		int[][] listeaAjouter= new int[tableau.length+1][2];
		listeaAjouter[0][0]=0;
		boolean couleurTrouver=false;
		boolean murTrouver=false;

		/* System.out.println("On recherche");
		System.out.println("" + coordonnee[0] +" " + coordonnee[1]);
		System.out.println("" + Directionligne +" " + DirectionColonne); */

		while(couleurTrouver==false && murTrouver==false){

			if (ligne+directionLigne> tableau.length-1 || ligne+directionLigne < 0 ||
				colonne+directionColonne> tableau[0].length-1 || colonne+directionColonne <0 ||  tableau[ligne+directionLigne][colonne+directionColonne]==0){
				murTrouver=true;  ///////////// ON VERIFIE QU'ON NE SORT PAS DU PLATEAU OU QU'ON RETOMBE PAS SUR UNE CASE VIDE 
			}
			else{

				if( tableau[ligne+directionLigne][colonne+directionColonne]==couleurAtrouver){
					couleurTrouver=true;
				}
				listeaAjouter[0][0]+=1;
				listeaAjouter[listeaAjouter[0][0]][0]=ligne;/////////////// ON AJOUTE LA CASE ACTUELLE
				listeaAjouter[listeaAjouter[0][0]][1]=colonne;

				ligne=ligne+directionLigne;
				colonne=colonne+directionColonne;
			}

		}
		/// UNE FOIS TOUT LES POINTS AJOUTER DANS LISTE A AJOUTER ON AJOUTER TOUT SI LA COULEUR EST TROUVE
		if (couleurTrouver==true){
			ajouterToutLesPoints(pointsModifier,listeaAjouter);
		}

	}

	public void ajouterToutLesPoints(int[][] listeDeBase,int[][] listeaAjouter){
		/// AJOUTE UNE LISTE DE COORDONNEE A UNE LISTE DE BASE ( ON L'UTILISERA ICI POUR AJOUTER LES CHEMINS CORRECT A LA LISTE DE POINT A MODIFIER)
		int tailleListeDeBase=listeDeBase[0][0];
		int tailleListeaAjouter=listeaAjouter[0][0];

		for (int i=1 ; i<= tailleListeaAjouter ; i++ ){

			listeDeBase[tailleListeDeBase+i]=listeaAjouter[i];
			listeDeBase[0][0]+=1;

		}
	}


	public void modifierBoard(int[][] pointsModifier,int couleur){
		// VA MODIFIER CHAQUES POINTS DU TABLEAU PAR UNE COULEUR DONNE

		for (int i=1;i<=pointsModifier[0][0];i++){
			tableau[pointsModifier[i][0]][pointsModifier[i][1]]=couleur;

		}
	}

	public boolean  caseVide(int Ligne,int Colonne){
		/// VERIFIE QU'UNE CASE EST BIEN VIDE (0 dedans)
		if (tableau[Ligne][Colonne]==0){
			return true;
		}
		else{
			return false;
		}
	}
	public boolean rougeBleuePresente(){
		// VERIFIE QU'IL EXISTE AU MOINS 1 ROUGE ET 1 BLEUE
		boolean blue =false;
		boolean red =false;
		for (int i=0;i < tableau.length;i++ ){
			for (int j=0;j < tableau[0].length;j++ ){
				if (tableau[i][j]==2){
					blue=true;
				}
				if (tableau[i][j]==1){
					red=true;
				}
			}
		}
		if (red && blue){
			return true;
		}
		else{
			return false;
		}
	}

	public void gagnantJeu(){
		/// FONCTION QUI DONNERA SUR LA CONSOLE LE NOMBRE DE POINT AINSI QUE LE GAGNANT
		int blue =0;
		int red =0;
		for (int i=0;i < tableau.length;i++ ){
			for (int j=0;j < tableau[0].length;j++ ){
				if (tableau[i][j]==2){
					blue+=1;
				}
				if (tableau[i][j]==1){
					red+=1;
				}
			}
		}
		System.out.println(" Rouge: "+red+"- Bleue: "+blue);
		if(red>blue){
			System.out.println("Le joueur rouge gagne !");
		}
		else 
			if(blue>red){
				System.out.println("Le joueur bleue gagne !");
			}
			else{
				System.out.println("Match nul ! Bien jou�");
			}
	}
}